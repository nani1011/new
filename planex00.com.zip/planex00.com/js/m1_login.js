var current_scrollY;
//open
$('.m1-loginOpen').on('click', function() {
  //fixed scroll
  current_scrollY = $(window).scrollTop();
  $('body').css({
    position: 'fixed',
    width: '100%',
    top: -1 * current_scrollY
  });
  //show
  $('#m1-login').addClass('is-show');
});

//close
$('.m1-loginClose').on('click', function() {
  //scroll
  $('body').attr({
    style: ''
  });
  $('html,body').prop({
    scrollTop: current_scrollY
  });
  //hide
  $('#m1-login').removeClass('is-show');
  //remove errorMessage text
  $('#error_mes').html('');
});
