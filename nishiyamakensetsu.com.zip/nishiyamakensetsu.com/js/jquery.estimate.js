$(function(){
	// ---------------------------------------------------------------------------------------------
	// ページ固有サイドバーの各挙動設定
	// ---------------------------------------------------------------------------------------------
	
	var ah = $('#order_view').outerHeight();
	var bh = $('#pdf_view').outerHeight();
	var maxh = (ah > bh)? ah: bh;
	var nowh = ah;
	
	$('#side_estprice').find('.toggle').hide();
	$('#estprice_slide').height(nowh);
	function side_ctrl() {
		$('#side_estprice').stickySidebar({
			speed:200,
			easing:'swing',
			padding:20,
			constrain:true
		});
	}
	side_ctrl();
	
	$('#order_view .pageslide a').click(function(){ // 右にスライド
		nowh = maxh;
		$('#estprice_slide').animate({ height:nowh },'fast','easeOutCubic',function(){
			$('#order_view').animate({ left:'-230px', opacity:0.2 });
			$('#pdf_view').animate({ left:0, opacity:1 },{
				complete: function(){
					nowh = bh;
					$('#side_estprice').find('.toggle').slideDown('fast','easeOutCubic');
					$('#estprice_slide').animate({ height:nowh },'fast','easeOutCubic',side_ctrl);
				}
			});
		});
		return false;
	});
	$('#pdf_view .pageslide a').click(function(){ // 左にスライド
		nowh = maxh;
		$('#side_estprice').find('.toggle').slideUp('fast','easeOutCubic');
		$('#estprice_slide').animate({ height:nowh },'fast','easeOutCubic',function(){
			$('#order_view').animate({ left:0, opacity:1 });
			$('#pdf_view').animate({ left:'250px', opacity:0.2 },{
				complete: function(){
					nowh = ah;
					$('#estprice_slide').animate({ height:nowh },'fast','easeOutCubic',side_ctrl);
				}
			});
		});
		return false;
	});
	
	// ---------------------------------------------------------------------------------------------
	// フォームの各挙動設定
	// ---------------------------------------------------------------------------------------------
	
	// タグ
	
	
	// 熨斗印刷（下部）
	if (!$('.est_noshi_btm select option').eq(2).prop('selected')) {
		$('.hide_area').hide();
	}
	$('.est_noshi_btm select').change(function() {
		if( $(this).val() == "タオルとは違う内容" ) {
			$(this).next('.hide_area').slideDown();
		} else {
			$(this).next('.hide_area').slideUp();
		}
	});
	
	
});