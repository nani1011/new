$(window).on("load", function () {
    // var height = $('#cm_header').height();
    $('a[href^=#]').click(function () {
        var target = $(this.hash);
        if (target.length) {
            $('html,body').animate({
                scrollTop: target.offset().top
            }, 1000);
            return false;
        }
    });

});


/* SmartRollover.js */
function smartRollover() {

    if (document.getElementsByTagName) {
        var images = document.getElementsByTagName("img");

        for (var i = 0; i < images.length; i++) {
            if (images[i].src.match("_off.")) {
                images[i].onmouseover = function () {
                    this.setAttribute("src", this.getAttribute("src").replace("_off.", "_on."));
                }
                images[i].onmouseout = function () {
                    this.setAttribute("src", this.getAttribute("src").replace("_on.", "_off."));
                }
            }
        }
    }
}
if (window.addEventListener) {
    window.addEventListener("load", smartRollover, false);
} else if (window.attachEvent) {
    window.attachEvent("onload", smartRollover);
}

/* Scroll link */

$(function () {
    var btn = $("#page_up");
    $(window).scroll(function () {
        if ($(this).scrollTop() > 150) {
            btn.fadeIn();
        } else {
            btn.fadeOut();
        }
    });
});


/* Mainmenu JavaScript */
$('.navTrigger').click(function () {
    $(this).toggleClass('active');
    $('.sp_sec').slideToggle('slow');
});

$(".h_sec .trigger_togg").hover(function () {
    $(this).toggleClass('opened').children('.sub_menu').stop().slideToggle('400');
    return false;
});

$(function () {
    //menu hide
    var menu = $('.sp_sec .trigger_togg .sub_menu');
    var trigger = $('.sp_sec .trigger_togg a');
    menu.hide();
    trigger.click(function () {
        menu.slideUp();
        trigger.removeClass('open');
        if ($(this).next(menu).is(':visible')) {
            $(this).next(menu).slideUp();
            $(this).removeClass('open');
        } else {
            $(this).next(menu).slideDown();
            $(this).addClass('open');
        }
    });
});


(function ($) {
    $.fn.tile = function (columns) {
        var tiles, max, c, h, last = this.length - 1,
            s;
        if (!columns) columns = this.length;
        this.each(function () {
            s = this.style;
            if (s.removeProperty) s.removeProperty("height");
            if (s.removeAttribute) s.removeAttribute("height");
        });
        return this.each(function (i) {
            c = i % columns;
            if (c == 0) tiles = [];
            tiles[c] = $(this);
            h = tiles[c].height();
            if (c == 0 || h > max) max = h;
            if (i == last || c == columns - 1)
                $.each(tiles, function () {
                    this.height(max);
                });
        });
    };
})(jQuery);
