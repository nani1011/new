$(function() {
    var timer = false;
    $(window).on('load resize', function() {
        if (timer !== false) {
            clearTimeout(timer);
        }
        timer = setTimeout(function() {
            setViewport(); // viewport
            linkTap(); // link tap
            accrodion_sp(); // accordion
        }, 200);
    });
});

// setViewport
function setViewport() {
    var w = $(window).width();
    var x = 767;
    var viewport = $('meta[name=viewport]');
    if (w <= x) {
        viewport.attr('content', 'width=device-width');
    } else {
        viewport.attr('content', 'width=1000');
    }
}

// SPのみアコーディオン - accordion (SP only)
function accrodion_sp() {
    var $acBtn = $('.ac_btn_sp');
    var $acBody = $('.ac_body_sp');
    if ($('#sp_visible').is(':visible')) {
        $acBtn.on("click", function(e) {
            $(this).next($acBody).not(":animated").slideToggle(200);
            $(this).toggleClass("open");
        });
    } else {
        $acBtn.off("click");
    }
}

// PCのみ電話番号をリンク不可にする - to disable link of telephone number (PC only)
function linkTap() {
    $('.link_tap').on('click', function() {
        if ($('#pc_visible').is(':visible')) {
            return false;
        }
    });
}

$(function() {
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
});
// gnav
// ==================================================

// TAB/SP用グローバルナビ - global navigation button for TAB/SP
$(function() {
    var
        body = $('body'),
        wrapper = $('#wrapper'),
        menu = $('#gnav'),
        menuBtn = $('#gnav_open'),
        closeBtn = $('#gnav_close'),
        menuWidth = menu.outerWidth(),
        hsize = $(window).height();

    function showMenu(event) {
        event.preventDefault();
        SPcurrentScroll = $(window).scrollTop();
        body.css({
            position: 'fixed',
            width: '100%',
            top: -1 * SPcurrentScroll
        });
        var shade = $('<div></div>');
        shade.attr('class', 'nav_shade').on('click', hideMenu);
        menu.before(shade).addClass('openMenu').css('max-height', hsize);
    }

    function hideMenu(event) {
        event.preventDefault();
        menu.outerWidth();
        body.attr('style', '');
        $('html, body').prop({ scrollTop: SPcurrentScroll });
        menu.prop({ scrollTop: 0 }).removeClass('openMenu').attr('style', '');
        $('.nav_shade').remove();
    }
    //メニュー開閉の実行
    $(window).on('load resize', function() {
        menu.outerWidth();
    });
    menuBtn.on('click', showMenu);
    closeBtn.on('click', hideMenu);
});

//smartRollover.js
function smartRollover() {
    if (document.getElementsByTagName) {
        var images = document.getElementsByTagName("img");

        for (var i = 0; i < images.length; i++) {
            if (images[i].src.match("_off.")) {
                images[i].onmouseover = function() {
                    this.setAttribute("src", this.getAttribute("src").replace("_off.", "_on."));
                }
                images[i].onmouseout = function() {
                    this.setAttribute("src", this.getAttribute("src").replace("_on.", "_off."));
                }
            }
        }
    }
}

if (window.addEventListener) {
    window.addEventListener("load", smartRollover, false);
} else if (window.attachEvent) {
    window.attachEvent("onload", smartRollover);
}

$(document).ready(function() {
    var flag = false;
    var page_up = $('.page_up');
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            if (flag == false) {
                if ($(window).width() > 767) {
                    flag = true;
                    page_up.stop().animate({
                        'right': '50px'
                    }, 500);
                }
                else{
                    flag = true;
                    page_up.stop().animate({
                        'right': '5%'
                    }, 500);
                }
            }
        } else {
            if (flag) {
                flag = false;
                page_up.stop().animate({
                    'right': '-500px'
                }, 500);
            }
        }
    });
    page_up.click(function() {
        $('body, html').animate({ scrollTop: 0 }, 500);
        return false;
    });
});

$(function() {
    var nav = $('header');
    //表示位置
    var nav_fix = $('nav');
    var navTop = nav.offset().top + 100;
    //ナビゲーションの高さ（シャドウの分だけ足してます）
    var navHeight = nav.height() + 10;
    var showFlag = false;
    nav.css('top', 0 + 'px');
    //ナビゲーションの位置まできたら表示
    $(window).scroll(function() {
        var winTop = $(this).scrollTop();
        if ($(window).width() > 767) {
            if (winTop >= 110) {
                if (showFlag == false) {
                    $(".hide").hide();
                    showFlag = true;
                    nav.addClass('fixed').stop();
                    nav_fix.animate({ 'top': '0px' }, 500);
                }
            } else if (winTop <= 110) {
                if (showFlag) {
                    $(".hide").show();
                    showFlag = false;
                    nav.stop().animate(200, function() {
                        nav.removeClass('fixed');
                    });
                }
            }
        } else {
            if (winTop >= navTop) {
                if (showFlag == false) {
                    $(".hide").hide();
                    showFlag = true;
                    nav.addClass('fixed_sp').stop();
                    nav.animate({ 'top': '0' }, 500);
                }
            } else if (winTop <= navTop) {
                if (showFlag) {
                    $(".hide").show();
                    showFlag = false;
                    nav.stop().animate(200, function() {
                        nav.removeClass('fixed_sp');
                    });
                }
            }
        }
    });
});

(function($) {
    $.fn.tile = function(columns) {
        var tiles, max, c, h, last = this.length - 1,
            s;
        if (!columns) columns = this.length;
        this.each(function() {
            s = this.style;
            if (s.removeProperty) s.removeProperty("height");
            if (s.removeAttribute) s.removeAttribute("height");
        });
        return this.each(function(i) {
            c = i % columns;
            if (c == 0) tiles = [];
            tiles[c] = $(this);
            h = tiles[c].height();
            if (c == 0 || h > max) max = h;
            if (i == last || c == columns - 1)
                $.each(tiles, function() { this.height(max); });
        });
    };
})(jQuery);
$(window).load(function() {
    $('.b_l_w .b_l_w_03 dl dt').tile(2);
});
$(window).resize(function() {
    $('.b_l_w .b_l_w_03 dl dt').tile(1);
});

$(document).ready(function() {
    $(window).on("resize", function() {
        if ($(window).width() > 767) {
        }
        if ($(window).width() < 767) {
            return false;
        }
    }).resize();

})

$(".overlay a").hover(
    function() {
        $(this).parents('.overlay').prev().addClass("active");
        $(this).parents('.box').addClass("on");
        console.log('test');
    },
    function() {
        $(this).parents('.overlay').prev().removeClass("active");
        $(this).parents('.box').removeClass("on");
    }
);

/*$(function() {
    var nav = $('.gnav');
    var ua = navigator.userAgent;
    var navTop = nav.offset().top;
    if ($(window).width() < 767) {
        // スマホのとき
        {
            $("li a",nav).click(function() {
                ly = $(this).parent();
                if (ly.hasClass("open")) {
                    ly.removeClass("open").find("ul").slideUp();
                } else {
                    ly.siblings().removeClass("open").find(".sub-menu").slideUp();
                    ly.addClass("open").find(">ul").slideDown();
                }
                return false;
            });
        }
    } else if ($(window).width() > 767) {
        $("li.sub",nav).hover(function() {
            $('.inner.child', this).stop().slideDown('fast');
            $(this).addClass('open');
        }, function() {
            $('.inner.child', this).stop().slideUp('fast');
            $(this).removeClass('open');
        });
    }
})*/
if ($(window).width() < 767) {
    // スマホのとき
    {
        $('.gnav li.sub').click(function() {
            ly = $(this);
            if (ly.hasClass("open")) {
                ly.removeClass("open").find("ul").slideUp();
            } else {
                ly.siblings().removeClass("open").find(".sub-menu").slideUp();
                ly.addClass("open").find(">ul").slideDown();
            }
            return false;
        });
    }
} else if ($(window).width() > 767) {
    $('.gnav li.sub').hover(function() {
        $('.inner.child', this).stop().slideDown('fast');
        $(this).addClass('open');
    }, function() {
        $('.inner.child', this).stop().slideUp('fast');
        $(this).removeClass('open');
    });
}
/*$('#gnav li.sub').hover(function() {
            $('.inner.child', this).stop().slideDown('fast');
            $(this).addClass('open');
        }, function() {
            $('.inner.child', this).stop().slideUp('fast');
            $(this).removeClass('open');
        });*/


$('.thumnail li a').click(function() {
    ly = $(this).parent();
    if (ly.hasClass("active")) {
        ly.removeClass("active");
    } else {
        ly.siblings().removeClass("active");
        ly.addClass("active");
    }
    return false;
});
$(".f_nav .site").click(function() {
    $(this).next('.flex').toggleClass('active');
    $(this).parent().toggleClass('opened');
    $(this).next('.flex').slideToggle('400');
    return false;
});
$('.f_nav li.sub').click(function() {
    ly = $(this);
    if (ly.hasClass("open")) {
        ly.removeClass("open").find("ul").slideUp();
    } else {
        ly.siblings().removeClass("open").find(".sub-menu").slideUp();
        ly.addClass("open").find(">ul").slideDown();
    }
    return false;
});
$(".hamburger").click(function() {
    $('#gnav').toggleClass('show');
    $(this).toggleClass('opened');
    $('#gnav').slideToggle('400');
    return false;
});
//RollOverImage(DW)

function MM_swapImgRestore() { //v3.0
    var i, x, a = document.MM_sr;
    for (i = 0; a && i < a.length && (x = a[i]) && x.oSrc; i++) x.src = x.oSrc;
}

function MM_preloadImages() { //v3.0
    var d = document;
    if (d.images) {
        if (!d.MM_p) d.MM_p = new Array();
        var i, j = d.MM_p.length,
            a = MM_preloadImages.arguments;
        for (i = 0; i < a.length; i++)
            if (a[i].indexOf("#") != 0) {
                d.MM_p[j] = new Image;
                d.MM_p[j++].src = a[i];
            }
    }
}

function MM_findObj(n, d) { //v4.01
    var p, i, x;
    if (!d) d = document;
    if ((p = n.indexOf("?")) > 0 && parent.frames.length) {
        d = parent.frames[n.substring(p + 1)].document;
        n = n.substring(0, p);
    }
    if (!(x = d[n]) && d.all) x = d.all[n];
    for (i = 0; !x && i < d.forms.length; i++) x = d.forms[i][n];
    for (i = 0; !x && d.layers && i < d.layers.length; i++) x = MM_findObj(n, d.layers[i].document);
    if (!x && d.getElementById) x = d.getElementById(n);
    return x;
}

function MM_swapImage() { //v3.0
    var i, j = 0,
        x, a = MM_swapImage.arguments;
    document.MM_sr = new Array;
    for (i = 0; i < (a.length - 2); i += 3)
        if ((x = MM_findObj(a[i])) != null) {
            document.MM_sr[j++] = x;
            if (!x.oSrc) x.oSrc = x.src;
            x.src = a[i + 2];
        }
}

function MM_openBrWindow(theURL, winName, features) { //v2.0
    window.open(theURL, winName, features);
}