var modalActive = 0;
var totalProduct = [];
var check = [];
$(document).ready(function () {
    $('.modal-toggle').on('click', function (e) {
        e.preventDefault();
        modelButton = $(this);
        dataModal = modelButton.data('modal');
        modalActive = dataModal;

        if ($('.package_item .modal').hasClass('is-visible')) {
            $('.package_item .modal').removeClass('is-visible').removeClass('block-scroll');
            $('html').toggleClass('ovr_hidden');
        } else {
            $('.package_item').find('div[data-modal*="' + dataModal + '"]').addClass('is-visible').addClass('block-scroll');
            $('html').toggleClass('ovr_hidden');
        }
    });

    $('.control-checkbox').on('change', function () {
        var a = $(this).find('.text').text();
        var data = $(this).parent().attr('data-add');
        $(this).toggleClass('active');
        // save item when choose in the modal
        var item = {
            data: data,
            lable: a
        }
        totalProduct.push(item);

        // append item li
        if ($(this).hasClass('active')) {
            if (modalActive === 1) {
                $(this).closest('.inner02_checkbox')
                    .find('#select1')
                    .children('ul')
                    .append('<li data-add=' + data + ' onClick="removeItem(this)">' + a + '</li>');
            } else if (modalActive === 2) {
                $(this).closest('.inner02_checkbox')
                    .find('#select2')
                    .children('ul')
                    .append('<li data-add=' + data + ' onClick="removeItem(this)">' + a + '</li>');
            } else if (modalActive === 3) {
                $(this).closest('.inner02_checkbox')
                    .find('#select3')
                    .children('ul')
                    .append('<li data-add=' + data + ' onClick="removeItem(this)">' + a + '</li>');
            } else if (modalActive === 4) {
                $(this).closest('.inner02_checkbox')
                    .find('#select4')
                    .children('ul')
                    .append('<li data-add=' + data + ' onClick="removeItem(this)">' + a + '</li>');
            } else if (modalActive === 5) {
                $(this).closest('.inner02_checkbox')
                    .find('#select5')
                    .children('ul')
                    .append('<li data-add=' + data + ' onClick="removeItem(this)">' + a + '</li>');
            } else {
                $(this).closest('.inner02_checkbox')
                    .find('#select6')
                    .children('ul')
                    .append('<li data-add=' + data + ' onClick="removeItem(this)">' + a + '</li>');
            }
        }
        else {
            $(this).closest('.inner02_checkbox')
                .find('.modal-selected')
                .children('ul')
                .find('[data-add=' + data + ']').text(a).detach();
            $(this).find('input').prop('checked', false);
            for (var i = totalProduct.length - 1; i >= 0; i--) {
                if (totalProduct[i].data === data) {
                    let a = totalProduct[i].data;
                    totalProduct.splice(i, 1);
                    check[a] = false;
                }
            }
        }
    });

    //search product
    $('.btnSearch, .modal-overlay').on('click', function () {
        $('.package_item .modal').removeClass('is-visible').removeClass('block-scroll');
        $('html').toggleClass('ovr_hidden');
        loadTotalProduct();
    });

});

// remove item on the model
function removeItem(e) {
    let modalBody = $(e).closest('.modal-body');
    let item = $(e).data('add');
    check[item] = false;
    $(e).remove();
    $('.list_check_box [data-add="' + item + '"] .control-checkbox').removeClass('active');
    $('.modal-selected [data-add="' + item + '"]').remove();
    $('.list_check_box [data-add="' + item + '"] .control-checkbox').find('input').prop('checked', false);
    let checkBody = $('.inner02_checkbox');
    checkBody.find('.condition.modal-selected ul li[data-add*="' + item + '"]').remove();
    if (item !== null) {
        for (var i = totalProduct.length - 1; i >= 0; i--) {
            if (totalProduct[i].data === item) {
                totalProduct.splice(i, 1);
            }
        }
    }
}

// load last product
function loadTotalProduct() {
    var html = $('#lastProduct').html();
    for (var i = 0; i < totalProduct.length; i++) {
        let a = totalProduct[i].data;
        if (!check[a]) {
            html += '<li data-add=' + totalProduct[i].data + ' onClick="removeItem(this)">' + totalProduct[i].lable + '</li>';
            check[a] = true;
        }
    }
    $('#lastProduct').html(html);
}