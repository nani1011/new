<?php
/**
 * インクルード処理用関数
 */

if (is_file(__DIR__ . "/config.php")) {
    require_once __DIR__ . "/config.php";
}

// SP階層？
$SP_FLG = (strpos(__DIR__, '/sp/') !== false) ? true : false;

/**
 * [getSEO description].
 * @return [type] [description]
 */
function getSEO()
{
    global $SP_FLG;
    // yamlの読込
    require_once 'Spyc.php'; // yamlライブラリ
    $data = spyc_load_file(($SP_FLG) ? __DIR__ . '/../../common/seo.yaml' : __DIR__ . '/seo.yaml');

    if (!is_array($data)) {
        exit('yaml file error');
    }

    foreach ($data['seo'] as $v) {
        if (strpos($_SERVER['REQUEST_URI'], $v['page']) !== false) {
            return $v;
        }
    }

    // 一致するのがなかったら
    return $data['default'];
}

// PCのcommonにyamlファイルがあるかのチェック
if ((!$SP_FLG and is_file(__DIR__ . '/seo.yaml')) or ($SP_FLG and is_file(__DIR__ . '/../../common/seo.yaml'))) {
    $SEO = getSEO();

    define('SEO_TITLE', $SEO['title']);
    define('SEO_DESCRIPTION', $SEO['description']);
    define('SEO_KEYWORDS', $SEO['keywords']);
    define('SEO_H1', $SEO['h1']);
}

/**
 * sample code
 *
 * <title><?=SEO_TITLE?></title>
 * <meta name="description" content="<?=SEO_DESCRIPTION?>">
 * <meta name="Keywords" content="<?=SEO_KEYWORDS?>">
 */

// 相対パスを取得

//このサイトのＴＯＰ階層を抽出する（裏側のファイルのパスなどに使用）
$base_path = str_replace("/common", "", dirname(__FILE__));

//ドキュメントルート ディレクトリのパスを除去する
$inc_path = str_replace($_SERVER['DOCUMENT_ROOT'], '', $base_path) . '/';

// ディレクトリ名
$plc = basename(dirname($_SERVER['PHP_SELF']));

/**
 * function で内容を出力案件によって、左・右メニュー、フッターに動的カテゴリーなど
 * データベースへの接続が必要な場合がある。
 * 変数名を多く使うと、同じ変数名を使用されてしまい誤動作を起こす可能性があるためfunctionを使用
 * （変数が初期化されていないと表示内容のデータが出てしまう、別なところで配列で使っているなどがある場合）
 * 置換をすれば楽にパスが変更できる
 * href="../ → href="{$inc_path}
 * src="../ → src="{$inc_path}
 */

/**
 * ヘッダー用
 */
function DispHeader()
{
    global $inc_path;

    /**
     * variable functions
     * <h1>{$cname('SEO_H1')}</h1>
     */
    $cname = 'constant';

    $html = <<<EDIT
    
    <header id="header" class="header_top">
            <section class="content">
                <div class="h_head">
                    <div class="h_logo">
                        <a href="{$inc_path}">
                            <figure class="pc"><img src="{$inc_path}common_img/h_logo.png" alt="カネタ織物株式会社"></figure>
                            <figure class="sp"><img src="{$inc_path}common_img/h_logo_sp.png" alt="カネタ織物株式会社"></figure>
                        </a>
                    </div>
                    <div class="sp hamburger hamburger--stand js-hamburger">
                        <div class="hamburger-box">
                            <div class="hamburger-inner"></div>
                        </div>
                    </div>
                    <div class="nav">
                        <div class="content_r">
                            <div class="h_button">
                                <div class="bt h_news">
                                    <a href="{$inc_path}news/">News</a>
                                </div>
                                <div class="bt h_shop">
                                    <a href="{$inc_path}english/">English</a>
                                </div>
                            </div>
                            <nav id="gnav">
                                <ul class="clearfix">
                                    <li><a href="{$inc_path}about/">カネタ織物について</a></li>
                                    <li><a href="{$inc_path}product/">製品・サービス</a></li>
                                    <li><a href="{$inc_path}#mm">設備・工程</a></li>
                                    <li><a href="{$inc_path}">カネタの高密度織物</a></li>
                                    <li><a href="{$inc_path}">会社概要</a></li>
                                    <!--<li class="sub nav_pc">
                                        <a href="{$inc_path}">事業内容</a>
                                        <ul class="inner child sub-menu">
                                            <li><a href="{$inc_path}">事業内容</a></li>
                                            <li><a href="{$inc_path}">事業内容</a></li>
                                            <li><a href="{$inc_path}">事業内容</a></li>
                                        </ul>
                                    </li>-->
                                </ul>
                            </nav>
                        </div>
                        <div class="content_r2">
                            <div class="bt phone">
                                <a href="tel:0537482181"><img src="{$inc_path}common_img/ico_phone.png" alt="p"><span class="pc_db">0537-48-2181</span></a>
                            </div>
                            <div class="bt h_contact">
                                <a href="{$inc_path}contact/"><span class="pc_db">お問い合わせ</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </header>

    
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}


function DispHeader2()
{
    global $inc_path;
    $html = <<<EDIT

    
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}
/**
 * サイド
 */
function DispSide()
{
    global $inc_path;

    $html = <<<EDIT
    
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}

/**
 * フッター
 */
function DispFooter()
{
    global $inc_path;

    $html = <<<EDIT
    <footer>
            <div class="page_up">
                <a href="#wrapper">
                    <img class="totop" src="{$inc_path}common_img/pageup.png" alt="up">
                </a>
            </div>
            <section class="f_inner container clearfix">
                <div class="f_logo">
                    <div class="logo">
                        <a href="{$inc_path}"><img src="{$inc_path}common_img/f_logo.png" alt="トモエ算盤株式会社"></a>
                    </div>
                    <p class="f_add">〒473-1303 静岡県掛川市沖之須1358-1<br> TEL:<a href="tel:0537482181" class="tel_link white">0537-48-2181</a>
                    </p>
                </div>
                <div class="f_nav">
                    <ul>
                        <li><a href="{$inc_path}">ホーム</a></li>
                        <li><a href="{$inc_path}about/">カネタ織物について</a></li>
                        <li><a href="{$inc_path}product/">製品・サービス</a></li>
                        <li><a href="{$inc_path}">設備・工程</a></li>
                        <li><a href="{$inc_path}">カネタの高密度織物</a></li>
                        <li class="pc"><a href="{$inc_path}">お知らせ</a></li>
                        <li class="pc"><a href="{$inc_path}contact/">お問い合わせ</a></li>
                        <li class="pc"><a href="{$inc_path}contact/#pp">個人情報保護方針</a></li>
                    </ul>
                    <ul>
                        <li class="sp"><a href="{$inc_path}">お知らせ</a></li>
                        <li class="sp"><a href="{$inc_path}contact/">お問い合わせ</a></li>
                        <li class="sp"><a href="{$inc_path}contact/#pp">個人情報保護方針</a>
                        </li>
                        <li><a href="{$inc_path}">English</a></li>
                    </ul>
                </div>
            </section>
        </footer>
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;

}

/**
 * 全ページに追加
 * headタグの開始の直後
 *
 * <head>
 * DispAfterHeadStartTag()
 *
 */
function DispAfterHeadStartTag()
{
    global $inc_path;

    $html = <<<EDIT
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}

/**
 * 全ページに追加
 * headタグの閉じの直上
 *
 * DispBeforeHeadEndTag()
 * </head>
 *
 */
function DispBeforeHeadEndTag()
{
    global $inc_path;

    $html = <<<EDIT
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}

/**
 * 全ページに追加
 * bodyタグの開始の直後
 *
 * <body>
 * DispAfterBodyStartTag()
 *
 */
function DispAfterBodyStartTag()
{
    global $inc_path;

    $html = <<<EDIT
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}

/**
 * 全ページに追加
 * bodyタグの終了の直上
 *
 * DispBeforeBodyEndTag()
 * </body>
 *
 */
function DispBeforeBodyEndTag()
{
    global $inc_path;

    $html = <<<EDIT
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}

/**
 * アクセス解析用
 * 埋め込みたくないページ用にDispBeforeBodyEndTag()とは切り分ける
 */
function DispAccesslog()
{
    global $inc_path, $base_path, $SP_FLG;

    // プレビューはログを取らない
    if (!empty($_POST['act'])) {
        return $html;
    }

    $ua = $_SERVER['HTTP_USER_AGENT'];
    if (is_file("{$base_path}/log_sp.php") and ((strpos($ua, 'Android') !== false) and (strpos($ua, 'Mobile') !== false) or (strpos($ua, 'iPhone') !== false) or (strpos($ua, 'Windows Phone') !== false))) {
        // スマートフォンからアクセスされた場合
        $link_type = "log_sp.php";
    } elseif (is_file("{$base_path}/log_tb.php") and ((strpos($ua, 'Android') !== false) or (strpos($ua, 'iPad') !== false) or strpos($ua, 'Silk') !== false)) {
        // タブレットからアクセスされた場合
        $link_type = "log.php";
    } else {
        // デフォルトアクセス
        $link_type = "log.php";
    }

    // sp階層の場合は1つあげる
    if ($SP_FLG) {
        $inc_path .= '../';
    }

    $html = <<<EDIT
    <!-- ここから -->
    <script type="text/javascript" src="https://www.google.com/jsapi?key="></script>
    <script src="https://api.all-internet.jp/accesslog/access.js" language="javascript" type="text/javascript"></script>
    <script language="JavaScript" type="text/javascript">
    <!--
    var s_obj = new _WebStateInvest();
    document.write('<img src="{$inc_path}{$link_type}?referrer='+escape(document.referrer)+'&st_id_obj='+encodeURI(String(s_obj._st_id_obj))+'" width="1" height="1" style="display:none">');
    //-->
    </script>
    <!-- ここまで -->
EDIT;

    //内容を返す。（ここで表示だとショッピングのテンプレートでは表示が難しい為、データを返す）
    return $html;
}
