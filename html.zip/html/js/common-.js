$(function() {
    var timer = false;
    $(window).on('load resize', function() {
        if (timer !== false) {
            clearTimeout(timer);
        }
        timer = setTimeout(function() {
            setViewport(); // viewport
            linkTap(); // link tap
            accrodion_sp(); // accordion
        }, 200);
    });
});

// setViewport
function setViewport() {
    var w = $(window).width();
    var x = 767;
    var viewport = $('meta[name=viewport]');
    if (w <= x) {
        viewport.attr('content', 'width=device-width');
    } else {
        viewport.attr('content', 'width=1000');
    }
}

$(function() {
    setclass();
});

function setclass() {
    var w = $(window).width();
    var x = 767;
    var clas = $('.tab .flex');
    if (w <= x) {
        clas.addClass('slide');
    }
}


// SPのみアコーディオン - accordion (SP only)
function accrodion_sp() {
    var $acBtn = $('.ac_btn_sp');
    var $acBody = $('.ac_body_sp');
    if ($('#sp_visible').is(':visible')) {
        $acBtn.on("click", function(e) {
            $(this).next($acBody).not(":animated").slideToggle(200);
            $(this).toggleClass("open");
        });
    } else {
        $acBtn.off("click");
    }
}

// PCのみ電話番号をリンク不可にする - to disable link of telephone number (PC only)
function linkTap() {
    $('.link_tap').on('click', function() {
        if ($('#pc_visible').is(':visible')) {
            return false;
        }
    });
}

// gnav
// ==================================================

// TAB/SP用グローバルナビ - global navigation button for TAB/SP
$(function() {
    var
        body = $('body'),
        wrapper = $('#wrapper'),
        menu = $('#gnav'),
        menuBtn = $('#gnav_open'),
        closeBtn = $('#gnav_close'),
        menuWidth = menu.outerWidth(),
        hsize = $(window).height();

    function showMenu(event) {
        event.preventDefault();
        SPcurrentScroll = $(window).scrollTop();
        body.css({
            position: 'fixed',
            width: '100%',
            top: -1 * SPcurrentScroll
        });
        var shade = $('<div></div>');
        shade.attr('class', 'nav_shade').on('click', hideMenu);
        menu.before(shade).addClass('openMenu').css('max-height', hsize);
    }

    function hideMenu(event) {
        event.preventDefault();
        menu.outerWidth();
        body.attr('style', '');
        $('html, body').prop({ scrollTop: SPcurrentScroll });
        menu.prop({ scrollTop: 0 }).removeClass('openMenu').attr('style', '');
        $('.nav_shade').remove();
    }
    //メニュー開閉の実行
    $(window).on('load resize', function() {
        menu.outerWidth();
    });
    menuBtn.on('click', showMenu);
    closeBtn.on('click', hideMenu);
});

//smartRollover.js
function smartRollover() {
    if (document.getElementsByTagName) {
        var images = document.getElementsByTagName("img");

        for (var i = 0; i < images.length; i++) {
            if (images[i].src.match("_off.")) {
                images[i].onmouseover = function() {
                    this.setAttribute("src", this.getAttribute("src").replace("_off.", "_on."));
                }
                images[i].onmouseout = function() {
                    this.setAttribute("src", this.getAttribute("src").replace("_on.", "_off."));
                }
            }
        }
    }
}

if (window.addEventListener) {
    window.addEventListener("load", smartRollover, false);
} else if (window.attachEvent) {
    window.attachEvent("onload", smartRollover);
}
/*$(function() {
    var nav = $('.header_top');
    var mv = $('.main_visual');
    //表示位置
    var navTop = mv.height();
    var navTopsec = nav.offset().top + 100;
    //ナビゲーションの高さ（シャドウの分だけ足してます）
    var navHeight = nav.height() + 10;
    var showFlag = false;
    //nav.css('top', -navHeight + 'px');
    //ナビゲーションの位置まできたら表示
    $(window).scroll(function() {
        var winTop = $(this).scrollTop();
        if (winTop >= navTop) {
            if (showFlag == false) {
                $(".hide").hide();
                showFlag = true;
                nav.addClass('fixed').stop().animate({ 'top': '0px' }, 500);
                $('nav').addClass('fixed_nav');
            }
        } else if (winTop <= navTop) {
            if (showFlag) {
                $(".hide").show();
                showFlag = false;
                nav.stop().animate({ 'top': '0px' }, 200, function() {
                    nav.removeClass('fixed');
                    $('nav').removeClass('fixed_nav');
                });
            }
        }
    });
});*/
$(function() {
    var nav = $('header');
    //表示位置
    var navTop = nav.offset().top + 100;
    //ナビゲーションの高さ（シャドウの分だけ足してます）
    var navHeight = nav.height() + 10;
    var showFlag = false;
    nav.css('top', -navHeight + 'px');
    //ナビゲーションの位置まできたら表示
    $(window).scroll(function() {
        var winTop = $(this).scrollTop();
        if (winTop >= navTop) {
            if (showFlag == false) {
                $(".hide").hide();
                showFlag = true;
                nav.addClass('fixed').stop().animate({ 'top': '0px' }, 500);
            }
        } else if (winTop <= navTop) {
            if (showFlag) {
                $(".hide").show();
                showFlag = false;
                nav.stop().animate({ 'top': navHeight + 'px' }, 200, function() {
                    nav.removeClass('fixed');
                });
            }
        }
    });
});
$(document).ready(function() {
    var flag = false;
    var page_up = $('.page_up');
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            if (flag == false) {
                flag = true;
                page_up.stop().animate({
                    'right': '30px'
                }, 500);
            }
        } else {
            if (flag) {
                flag = false;
                page_up.stop().animate({
                    'right': '-500px'
                }, 500);
            }
        }
    });
    page_up.click(function() {
        $('body, html').animate({ scrollTop: 0 }, 500);
        return false;
    });
});

/*$(document).ready(function() {
    var flag = false;
    var side = $('.side');
    $(window).scroll(function() {
        if ($(this).scrollTop() > 10) {
            if (flag == false) {
                flag = true;
                side.stop().animate({
                    'right': '0'
                }, 500);
            }
        } else {
            if (flag) {
                flag = false;
                side.stop().animate({
                    'right': '-500px'
                }, 500);
            }
        }
    });
    side.click(function() {
        $('body, html').animate({ scrollTop: 0 }, 500);
        return false;
    });
});*/

(function($) {
    $.fn.tile = function(columns) {
        var tiles, max, c, h, last = this.length - 1,
            s;
        if (!columns) columns = this.length;
        this.each(function() {
            s = this.style;
            if (s.removeProperty) s.removeProperty("height");
            if (s.removeAttribute) s.removeAttribute("height");
        });
        return this.each(function(i) {
            c = i % columns;
            if (c == 0) tiles = [];
            tiles[c] = $(this);
            h = tiles[c].height();
            if (c == 0 || h > max) max = h;
            if (i == last || c == columns - 1)
                $.each(tiles, function() { this.height(max); });
        });
    };
})(jQuery);
$(window).load(function() {

});
$(window).resize(function() {});
$(document).ready(function() {

    $(window).on("resize", function() {
        if ($(window).width() > 767) {
            $('.top02 .inn h3').tile(4);
        }
        if ($(window).width() < 767) {
            $('.top02 .inn h3').tile(2);
        }
    }).resize();
})
$(document).ready(function() {
    $('.tabs .tab-links a').click(function() {
        var currentAttrValue = $(this).attr('href');
        $('.tabs ' + currentAttrValue).slideDown(400).siblings().slideUp(400);
        if ($('.tabs ' + currentAttrValue).hasClass("active")) {
            $('.tabs ' + currentAttrValue).removeClass("active");
        } else {
            $('.tabs ' + currentAttrValue).siblings().removeClass("active");
            $('.tabs ' + currentAttrValue).addClass("active");
        };
        if ($(this).parent('li').hasClass("active")) {
            $(this).parent('li').removeClass("active");
        } else {
            $(this).parent('li').siblings().removeClass("active");
            $(this).parent('li').addClass("active");
        }
        return false;
    });
});

$(document).ready(function() {
    var o = $(window).width();
    $(window).on("load touchstart scroll", function() {
        var e = 150;
        if (window.matchMedia("(min-width:769px)").matches) var e = 200;
        $(".animate").each(function() {
            o = $(this).offset().top - $(window).height() + e;
            $(window).scrollTop() >= o && $(this).addClass("animate--scrolled")
        });
    });
});
$(function() {
    $('.photo .thumnail li').click(function() {
        $(this).toggleClass('active');
    });
});

$(function() {
    $('a[href*=#]:not([href=#]) .link').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
});

(function() {

    'use strict';

    $(document).ready(function() {
        var rtime;
        var timeout = false;
        var delta = 200;
        var $window = $(window);

        if ($window.width() > 1023) {

            var ps = new PerfectScrollbar('.perfect_scroll');

            ps.update();

        }
    });
}());

if ($(window).width() < 767) {
    // スマホのとき
    {
        $('#gnav li.sub').click(function() {
            ly = $(this);
            if (ly.hasClass("open")) {
                ly.removeClass("open").find("ul").slideUp();
            } else {
                ly.siblings().removeClass("open").find(".sub-menu").slideUp();
                ly.addClass("open").find(">ul").slideDown();
            }
        });
    }
} else if ($(window).width() > 767) {
    $('#gnav li.sub').hover(function() {
        $('.inner.child', this).stop().slideDown('fast');
        $(this).addClass('open');
    }, function() {
        $('.inner.child', this).stop().slideUp('fast');
        $(this).removeClass('open');
    });
}
$(".hamburger").click(function() {
    $('.nav').toggleClass('show');
    $('header').toggleClass('active');
    $(this).toggleClass('opened');
    $('.nav #gnav').slideToggle('400');
    return false;
});
$(".overlay a").hover(
    function() {
        $(this).parents('.inn').find('figure').addClass("active");
    },
    function() {
        $(this).parents('.inn').find('figure').removeClass("active");
    }
);
$(function() {
    setTimeout('rect()');
});

function rect() {
    $('.main_list li a:after').hover({
        marginTop: '-=10px'
    }, 500).animate({
        marginTop: '+=10px'
    }, 500);
    setTimeout('rect()', 1000);
}

//RollOverImage(DW)

function MM_swapImgRestore() { //v3.0
    var i, x, a = document.MM_sr;
    for (i = 0; a && i < a.length && (x = a[i]) && x.oSrc; i++) x.src = x.oSrc;
}

function MM_preloadImages() { //v3.0
    var d = document;
    if (d.images) {
        if (!d.MM_p) d.MM_p = new Array();
        var i, j = d.MM_p.length,
            a = MM_preloadImages.arguments;
        for (i = 0; i < a.length; i++)
            if (a[i].indexOf("#") != 0) {
                d.MM_p[j] = new Image;
                d.MM_p[j++].src = a[i];
            }
    }
}

function MM_findObj(n, d) { //v4.01
    var p, i, x;
    if (!d) d = document;
    if ((p = n.indexOf("?")) > 0 && parent.frames.length) {
        d = parent.frames[n.substring(p + 1)].document;
        n = n.substring(0, p);
    }
    if (!(x = d[n]) && d.all) x = d.all[n];
    for (i = 0; !x && i < d.forms.length; i++) x = d.forms[i][n];
    for (i = 0; !x && d.layers && i < d.layers.length; i++) x = MM_findObj(n, d.layers[i].document);
    if (!x && d.getElementById) x = d.getElementById(n);
    return x;
}

function MM_swapImage() { //v3.0
    var i, j = 0,
        x, a = MM_swapImage.arguments;
    document.MM_sr = new Array;
    for (i = 0; i < (a.length - 2); i += 3)
        if ((x = MM_findObj(a[i])) != null) {
            document.MM_sr[j++] = x;
            if (!x.oSrc) x.oSrc = x.src;
            x.src = a[i + 2];
        }
}

function MM_openBrWindow(theURL, winName, features) { //v2.0
    window.open(theURL, winName, features);
}