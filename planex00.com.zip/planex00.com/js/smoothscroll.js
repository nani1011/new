$(function () {
    // cai nay tro den anchor link tu 1 link khac
    hashname = window.location.hash.replace('#', '');
    elem = $('#' + hashname);
    if(hashname.length > 1) {
      if(hashname == 'top') {
      $('body, html').animate({
              scrollTop: 0
          },200);
      } else {
      $('body, html').animate({
              scrollTop: $(elem).offset().top - 75 // tru cai nay khi dung header fixed de tru no ra
          },500);
      }
    };
    // cai nay tro den anchor link trong trang do
    $('a[href*=#]:not([href=#])').click(function () {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top - 75  // tru cai nay khi dung header fixed de tru no ra
                }, 1000);
                return false;
            }
        }
    });
});